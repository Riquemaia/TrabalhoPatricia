package br.fiap.entidade;

public class Prontuario {

	private boolean Covid19;

	public boolean getCovid19() {
		return Covid19;
	}

	public void setCovid19(boolean covid19) {
		Covid19 = covid19;
	}
	
	public Prontuario () {
		
	}
	
	
}
