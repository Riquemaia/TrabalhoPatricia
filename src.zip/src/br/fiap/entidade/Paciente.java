package br.fiap.entidade;

public class Paciente {

	private String nome;
	private long CPF;
	public Prontuario prontuario;

	public Paciente(String nome, long cpf) {
		this.nome = nome;
		CPF = cpf;		
		prontuario = new Prontuario();
		prontuario.setCovid19(false);
	}

	public String toString() {
		return this.nome+" "+this.CPF;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public long getCPF() {
		return CPF;
	}

	public void setCPF(long cPF) {
		CPF = cPF;
	}	
	
	
}
