package br.fiap.fila;

import br.fiap.entidade.Paciente;

public class FilaPaciente {

    private class NO {
        Paciente dado;
        NO prox;
    }

    private NO ini;
    private NO fim;

    public void init() {
        ini = fim = null;
    }

    public boolean isEmpty() {
        if (ini == null && fim == null) {
            return true;
        } else {
            return false;
        }
    }

    public void enqueue(Paciente elem) {
        NO novo = new NO();
        novo.dado = elem;
        novo.prox = null;
        if (isEmpty()) {
            ini = novo;
        } else {
            fim.prox = novo;
        }
        fim = novo;
    }

    public Paciente dequeue() {
        Paciente v = ini.dado;
        ini = ini.prox;
        if (ini == null) {
            fim = null;
        }
        return v;
    }

    public Paciente first() {
        return ini.dado;
    }

}