package br.fiap.fila;

import br.fiap.entidade.Paciente;

public class FilaVaga {

	    public final int N = 2;

	    Paciente dados[] = new Paciente[N];
	    int ini, fim, cont;

	    public void init() {
	        ini = fim = cont = 0;
	    }

	    public boolean isEmpty() {
	        if (cont == 0)
	            return true;
	        else
	            return false;
	    }

	    public boolean isFull() {
	        if (cont == N)
	            return true;
	        else
	            return false;
	    }

	    public void enqueue(Paciente elem) {
	        if (isFull() == false) {
	            dados[fim] = elem;
	            fim = (fim + 1) % N;
	            cont++;
	            /*
	             * outra forma de mover o fim: fim++; if (fim == N ) fim = 0;
	             */
	        } else
	            System.out.println("N�o h� mais vagas!");
	    }

	    public Paciente dequeue() {
	        Paciente valor = dados[ini];
	        cont--;
	        ini = (ini + 1) % N;
	        return valor;
	    }

	    public Paciente first() {
	        return dados[ini];
	    }
	
}
