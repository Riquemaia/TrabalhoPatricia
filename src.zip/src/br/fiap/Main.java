package br.fiap;

import java.util.Scanner;

import br.fiap.entidade.Paciente;
import br.fiap.fila.FilaPaciente;
import br.fiap.fila.FilaVaga;

public class Main {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int opcao;

		FilaPaciente filaAtend = new FilaPaciente();
		filaAtend.init();
		FilaVaga filaVaga = new FilaVaga();
		filaVaga.init();

		do {
			System.out.println(" ###### MENU ###### ");
			System.out.println("1- inserir paciente na fila");
			System.out.println("2- Atender paciente na fila");
			System.out.println("3- Sair");
			opcao = teclado.nextInt();
			teclado.nextLine();
			System.out.println();

			switch (opcao) {
			case 1:
				Paciente paciente = new Paciente(DigiteONome(teclado), DigiteOCPF(teclado));
				filaAtend.enqueue(paciente);

				break;
			case 2:
				if (!filaAtend.isEmpty()) {
					Paciente emAtendimento = filaAtend.dequeue();
					System.out.println("Paciente a ser atendido: " + emAtendimento.toString());
					emAtendimento.prontuario.setCovid19(VoceTemCovid());
					if(emAtendimento.prontuario.getCovid19()) {
						
						filaVaga.enqueue(emAtendimento);
					}

				} else {
					System.err.println("N�o h� pacientes na fila para serem executados");
				}

				break;
			case 3:
				if (filaAtend.isEmpty()) {
					System.out.print("Encerramos as atividades do dia");
				} else {
					System.out.println("H� pacientes na fila");
					opcao = 0;
				}

				break;

			default:
				System.out.println("Opcao inv�lida");

			}
			System.out.println();
		} while (opcao != 3);

		teclado.close();
	}

	private static boolean VoceTemCovid() {
		// TODO Auto-generated method stub
		int sintomas = 0;
		String resp;
		Scanner teclado = new Scanner(System.in);

		System.out.println("Voc� teve febre nos ultimos dias?");
		resp = teclado.nextLine();
		if (resp.equals("S"))
			sintomas++;

		System.out.println("Voc� teve tosse nos ultimos dias?");
		resp = teclado.nextLine();
		if (resp.equals("S"))
			sintomas++;
		
		System.out.println("Voc� teve dor de garganta nos ultimos dias?");
		resp = teclado.nextLine();
		if (resp.equals("S"))
			sintomas++;
		
		System.out.println("Voc� teve falta de ar nos ultimos dias?");
		resp = teclado.nextLine();
		if (resp.equals("S"))
			sintomas++;
		
		return sintomas > 2 ;
	}

	private static String DigiteONome(Scanner teclado) {
		// TODO Auto-generated method stub
		System.out.println("Digite o nome do paciente :");

		return teclado.nextLine();
	}

	private static long DigiteOCPF(Scanner teclado) {
		System.out.println("Digite o CPF do paciente :");

		return teclado.nextLong();
	}

}
