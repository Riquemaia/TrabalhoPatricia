package br.fiap.entidade;

public class Vaga {
	
	private Paciente paciente;

	public Vaga(Paciente paciente) {
		super();
		this.paciente = paciente;
	}
	
	
	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	
}
